My first readme in c programming
