My c Function readme
